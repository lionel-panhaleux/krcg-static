Name:
Finnish Nationals 2022

Date:
5.11.2022

VEKN page:
https://www.vekn.net/event-calendar/event/10367

Deck lists collected:
21/45

Notes:
Deck lists were collected voluntarily. This was a prototype for VTA's processing method.